# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="2.0.5"></a>
## [2.0.5](https://github.com/alexa/alexa-skills-kit-sdk-for-nodejs/compare/v2.0.4...v2.0.5) (2018-05-16)


### Bug Fixes

* update execution behavior of interceptor ([352f638](https://github.com/alexa/alexa-skills-kit-sdk-for-nodejs/commit/352f638))
