//=========================================================================================================================================
//This data quizzes users about the author and publication dates of well-known Japanese books.
//=========================================================================================================================================



var data = [
                {BookTitle: "伊豆の踊子", Author: "川端康成", OriginalPublicationDate:1927},
                {BookTitle: "ノルウェイの森", Author: "村上春樹", OriginalPublicationDate:1987},
                {BookTitle: "奥の細道", Author: "松尾芭蕉", OriginalPublicationDate:1702},
                {BookTitle: "こころ", Author: "夏目漱石", OriginalPublicationDate:1914},
                {BookTitle: "砂の女", Author: "安部公房", OriginalPublicationDate:1962},
                {BookTitle: "細雪",  Author: "谷崎潤一郎", OriginalPublicationDate:1944},
                {BookTitle: "窓ぎわのトットちゃん", Author: "黒柳徹子", OriginalPublicationDate:1981},
                {BookTitle: "銀河鉄道の夜", Author: "宮沢賢治", OriginalPublicationDate:1934},
                {BookTitle: "みだれ髪", Author: "与謝野晶子", OriginalPublicationDate:1901},
                {BookTitle: "人間失格", Author: "太宰治", OriginalPublicationDate:1948}
            ];
