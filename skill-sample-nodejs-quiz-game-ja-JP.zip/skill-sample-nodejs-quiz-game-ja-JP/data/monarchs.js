var data = [
        { Name:"徳川家康", YearOfCoronation:1603, Predecessor:"none", Successor:"徳川秀忠", YearOfDeath:1616},
        { Name:"徳川秀忠", YearOfCoronation:1605, Predecessor:"徳川家康", Successor:"徳川家光", YearOfDeath:1632},
        { Name:"徳川家光", YearOfCoronation:1623, Predecessor:"徳川秀忠", Successor:"徳川家綱", YearOfDeath:1651},
        { Name:"徳川家綱", YearOfCoronation:1651, Predecessor:"徳川家光", Successor:"徳川綱吉", YearOfDeath:1680},
        { Name:"徳川綱吉", YearOfCoronation:1680, Predecessor:"徳川家綱", Successor:"徳川家宣", YearOfDeath:1709},
        { Name:"徳川家宣", YearOfCoronation:1709, Predecessor:"徳川綱吉", Successor:"徳川家継", YearOfDeath:1712},
        { Name:"徳川家継", YearOfCoronation:1713, Predecessor:"徳川家宣", Successor:"徳川吉宗", YearOfDeath:1716},
        { Name:"徳川吉宗", YearOfCoronation:1716, Predecessor:"徳川家継", Successor:"徳川家重", YearOfDeath:1751},
        { Name:"徳川家重", YearOfCoronation:1745, Predecessor:"徳川吉宗", Successor:"徳川家治", YearOfDeath:1761},
        { Name:"徳川家治", YearOfCoronation:1760, Predecessor:"徳川家重", Successor:"徳川家斉", YearOfDeath:1786},
        { Name:"徳川家斉", YearOfCoronation:1787, Predecessor:"徳川家治", Successor:"徳川家慶", YearOfDeath:1841},
        { Name:"徳川家慶", YearOfCoronation:1837, Predecessor:"徳川家斉", Successor:"徳川家定", YearOfDeath:1853},
        { Name:"徳川家定", YearOfCoronation:1853, Predecessor:"徳川家慶", Successor:"徳川家茂", YearOfDeath:1858},
        { Name:"徳川家茂", YearOfCoronation:1858, Predecessor:"徳川家定", Successor:"徳川慶喜", YearOfDeath:1866},
        { Name:"徳川慶喜", YearOfCoronation:1867, Predecessor:"徳川家茂", Successor:"徳川家達", YearOfDeath:1913}
    ]